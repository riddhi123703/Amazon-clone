function changeFlag(){

let country = document.getElementById("country").value;

let flag = document.getElementById("flag");

flag.src = "https://flagcdn.com/w40/" + country + ".png";

}